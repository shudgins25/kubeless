import json
import urllib2

#event["data"] contains coordinate data e.g. "38.33,-75.08"
def getWeatherData(event, context):
  print event
  print context
  coords = event["data"]
  resp = urllib2.urlopen("https://api.weather.gov/points/" + coords)
  return resp.read()

