def hello(event, context):
  print event
  print context
  return "Hello World " + event['data']
