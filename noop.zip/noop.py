import json
import urllib2

#no op function to test performance
def getWeatherData(event, context):
  print event
  print context
  return event["data"]
